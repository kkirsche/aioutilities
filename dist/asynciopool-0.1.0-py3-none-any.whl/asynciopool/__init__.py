from importlib.metadata import version

__distribution_name__ = "asynciopool"
__version__ = version(distribution_name=__distribution_name__)
