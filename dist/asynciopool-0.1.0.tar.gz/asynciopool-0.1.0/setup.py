# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['asynciopool']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['asynciopool-example = asynciopool.example:run_example']}

setup_kwargs = {
    'name': 'asynciopool',
    'version': '0.1.0',
    'description': 'asyncio-powered coroutine worker pool',
    'long_description': None,
    'author': 'Kevin Kirsche',
    'author_email': 'kev.kirsche@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4',
}


setup(**setup_kwargs)
