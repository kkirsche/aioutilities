class Terminate:
    pass
